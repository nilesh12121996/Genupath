-- ══════════════════════════════════════════════════════════════
-- CareerPilot 2026 — PostgreSQL Schema (Week 1)
-- Compatible with both raw PostgreSQL (local) and Supabase (staging)
-- ══════════════════════════════════════════════════════════════

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── ENUM TYPES ──────────────────────────────────────────────

CREATE TYPE visa_status AS ENUM (
  'f1_opt', 'f1_cpt', 'f1_stem_opt', 'h4_ead',
  'h1b', 'h1b_cap', 'green_card', 'citizen', 'other'
);

CREATE TYPE ats_platform AS ENUM (
  'greenhouse', 'lever', 'workday', 'ashby',
  'icims', 'taleo', 'custom', 'unknown'
);

CREATE TYPE job_status AS ENUM (
  'raw', 'structured', 'matched', 'rejected',
  'applied', 'expired', 'closed'
);

CREATE TYPE application_status AS ENUM (
  'draft', 'resume_tailored', 'ats_scored',
  'pending_review', 'approved', 'submitting',
  'submitted', 'confirmed', 'failed', 'withdrawn'
);

CREATE TYPE proficiency_level AS ENUM (
  'beginner', 'intermediate', 'advanced', 'expert'
);

-- ── CANDIDATES ──────────────────────────────────────────────

CREATE TABLE candidates (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL UNIQUE,  -- Supabase Auth user ID
  name        TEXT NOT NULL,
  email       TEXT NOT NULL UNIQUE,
  location    TEXT,
  visa_status visa_status NOT NULL DEFAULT 'f1_opt',
  phone       TEXT,
  linkedin    TEXT,
  github      TEXT,
  portfolio   TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_candidates_user_id ON candidates(user_id);
CREATE INDEX idx_candidates_email ON candidates(email);
CREATE INDEX idx_candidates_visa ON candidates(visa_status);

-- ── EXPERIENCES ─────────────────────────────────────────────

CREATE TABLE experiences (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  company      TEXT NOT NULL,
  role         TEXT NOT NULL,
  start_date   DATE NOT NULL,
  end_date     DATE,          -- NULL = current role
  bullets      TEXT[] NOT NULL DEFAULT '{}',
  skills       TEXT[] NOT NULL DEFAULT '{}',
  is_current   BOOLEAN NOT NULL DEFAULT FALSE,
  location     TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_experiences_candidate ON experiences(candidate_id);
CREATE INDEX idx_experiences_company ON experiences(company);
CREATE INDEX idx_experiences_current ON experiences(candidate_id) WHERE is_current = TRUE;

-- ── SKILLS ──────────────────────────────────────────────────

CREATE TABLE skills (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  skill_name   TEXT NOT NULL,
  proficiency  proficiency_level NOT NULL DEFAULT 'intermediate',
  years        NUMERIC(3,1),  -- e.g. 2.5 years
  source       TEXT,          -- 'resume', 'manual', 'inferred'
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(candidate_id, skill_name)
);

CREATE INDEX idx_skills_candidate ON skills(candidate_id);
CREATE INDEX idx_skills_name ON skills(skill_name);

-- ── TRUTH CONSTRAINTS ───────────────────────────────────────
-- Guardrails: every AI-rewritten bullet must stay within these
-- bounds. Agent 3 cross-checks against this table.

CREATE TABLE truth_constraints (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  companies    TEXT[] NOT NULL DEFAULT '{}',   -- companies candidate actually worked at
  roles        TEXT[] NOT NULL DEFAULT '{}',   -- actual titles held
  date_ranges  JSONB NOT NULL DEFAULT '[]',    -- [{company, start, end}]
  skills       TEXT[] NOT NULL DEFAULT '{}',   -- verified skill set
  degrees      JSONB NOT NULL DEFAULT '[]',    -- [{school, degree, field, year}]
  certifications TEXT[] NOT NULL DEFAULT '{}',
  max_yoe      NUMERIC(3,1),                  -- max years of experience (prevents inflation)
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_truth_candidate ON truth_constraints(candidate_id);

-- ── JOBS ────────────────────────────────────────────────────

CREATE TABLE jobs (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source          TEXT NOT NULL,           -- 'greenhouse', 'lever', 'ashby', 'jobo'
  source_id       TEXT,                    -- external ID from ATS
  company         TEXT NOT NULL,
  title           TEXT NOT NULL,
  location        TEXT,
  remote_ok       BOOLEAN DEFAULT FALSE,
  ats_platform    ats_platform NOT NULL DEFAULT 'unknown',
  apply_url       TEXT NOT NULL,
  description     TEXT,                    -- cleaned JD text
  requirements    JSONB DEFAULT '[]',      -- structured requirements from Agent 1
  h1b_probability NUMERIC(3,2),            -- 0.00 to 1.00
  match_score     NUMERIC(5,2),            -- cosine similarity score
  status          job_status NOT NULL DEFAULT 'raw',
  raw_json        JSONB,                   -- original API response
  salary_min      INTEGER,
  salary_max      INTEGER,
  salary_currency TEXT DEFAULT 'USD',
  posted_at       TIMESTAMPTZ,
  expires_at      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(source, source_id)
);

CREATE INDEX idx_jobs_company ON jobs(company);
CREATE INDEX idx_jobs_status ON jobs(status);
CREATE INDEX idx_jobs_h1b ON jobs(h1b_probability) WHERE h1b_probability IS NOT NULL;
CREATE INDEX idx_jobs_match ON jobs(match_score DESC) WHERE match_score IS NOT NULL;
CREATE INDEX idx_jobs_created ON jobs(created_at DESC);
CREATE INDEX idx_jobs_source_id ON jobs(source, source_id);

-- ── APPLICATIONS ────────────────────────────────────────────

CREATE TABLE applications (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id      UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  job_id            UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  resume_version_id UUID,               -- reference to R2 object key
  ats_score         NUMERIC(5,2),       -- Jobscan score (0-100)
  status            application_status NOT NULL DEFAULT 'draft',
  submitted_at      TIMESTAMPTZ,
  confirmation_id   TEXT,               -- ATS confirmation number
  portal_session_id TEXT,               -- Skyvern session ID
  retry_count       INTEGER DEFAULT 0,
  error_log         JSONB,              -- last error details
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(candidate_id, job_id)          -- prevent duplicate applications
);

CREATE INDEX idx_applications_candidate ON applications(candidate_id);
CREATE INDEX idx_applications_job ON applications(job_id);
CREATE INDEX idx_applications_status ON applications(status);
CREATE INDEX idx_applications_submitted ON applications(submitted_at DESC)
  WHERE submitted_at IS NOT NULL;

-- ── RESUME VERSIONS (tracking tailored resumes) ─────────────

CREATE TABLE resume_versions (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  job_id       UUID REFERENCES jobs(id) ON DELETE SET NULL,
  r2_key       TEXT NOT NULL,          -- R2 object path
  file_hash    TEXT NOT NULL,          -- SHA-256 for dedup
  ats_score    NUMERIC(5,2),
  is_original  BOOLEAN DEFAULT FALSE,  -- original upload vs tailored
  metadata     JSONB DEFAULT '{}',     -- {latex_template, rewrite_model, etc}
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_resume_versions_candidate ON resume_versions(candidate_id);

-- ── AUDIT LOG (immutable, append-only) ──────────────────────

CREATE TABLE audit_log (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID,
  action     TEXT NOT NULL,
  entity     TEXT NOT NULL,           -- 'candidate', 'application', 'job', etc
  entity_id  UUID,
  details    JSONB DEFAULT '{}',
  ip_address INET,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- No UPDATE or DELETE allowed — enforced by RLS + trigger
CREATE INDEX idx_audit_created ON audit_log(created_at DESC);
CREATE INDEX idx_audit_user ON audit_log(user_id);
CREATE INDEX idx_audit_entity ON audit_log(entity, entity_id);

-- ── RLS POLICIES ────────────────────────────────────────────
-- In Supabase, auth.uid() returns the logged-in user's ID.
-- For local dev, these policies are created but not enforced
-- unless you SET app.current_user_id = '...' per session.

ALTER TABLE candidates ENABLE ROW LEVEL SECURITY;
ALTER TABLE experiences ENABLE ROW LEVEL SECURITY;
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE truth_constraints ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE resume_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- Candidates: users see only their own row
CREATE POLICY candidates_own ON candidates
  FOR ALL USING (
    user_id = COALESCE(
      current_setting('request.jwt.claim.sub', true)::uuid,
      current_setting('app.current_user_id', true)::uuid
    )
  );

-- Experiences: via candidate ownership
CREATE POLICY experiences_own ON experiences
  FOR ALL USING (
    candidate_id IN (
      SELECT id FROM candidates WHERE user_id = COALESCE(
        current_setting('request.jwt.claim.sub', true)::uuid,
        current_setting('app.current_user_id', true)::uuid
      )
    )
  );

-- Skills: via candidate ownership
CREATE POLICY skills_own ON skills
  FOR ALL USING (
    candidate_id IN (
      SELECT id FROM candidates WHERE user_id = COALESCE(
        current_setting('request.jwt.claim.sub', true)::uuid,
        current_setting('app.current_user_id', true)::uuid
      )
    )
  );

-- Truth constraints: via candidate ownership
CREATE POLICY truth_own ON truth_constraints
  FOR ALL USING (
    candidate_id IN (
      SELECT id FROM candidates WHERE user_id = COALESCE(
        current_setting('request.jwt.claim.sub', true)::uuid,
        current_setting('app.current_user_id', true)::uuid
      )
    )
  );

-- Applications: via candidate ownership
CREATE POLICY applications_own ON applications
  FOR ALL USING (
    candidate_id IN (
      SELECT id FROM candidates WHERE user_id = COALESCE(
        current_setting('request.jwt.claim.sub', true)::uuid,
        current_setting('app.current_user_id', true)::uuid
      )
    )
  );

-- Jobs: readable by all authenticated users (public listings)
CREATE POLICY jobs_read ON jobs
  FOR SELECT USING (true);

-- Resume versions: via candidate ownership
CREATE POLICY resume_versions_own ON resume_versions
  FOR ALL USING (
    candidate_id IN (
      SELECT id FROM candidates WHERE user_id = COALESCE(
        current_setting('request.jwt.claim.sub', true)::uuid,
        current_setting('app.current_user_id', true)::uuid
      )
    )
  );

-- Audit log: insert-only, readable by own user
CREATE POLICY audit_insert ON audit_log
  FOR INSERT WITH CHECK (true);

CREATE POLICY audit_read ON audit_log
  FOR SELECT USING (
    user_id = COALESCE(
      current_setting('request.jwt.claim.sub', true)::uuid,
      current_setting('app.current_user_id', true)::uuid
    )
  );

-- Prevent updates/deletes on audit log
CREATE OR REPLACE FUNCTION prevent_audit_modification()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Audit log is immutable — updates and deletes are forbidden';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER no_audit_update
  BEFORE UPDATE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION prevent_audit_modification();

CREATE TRIGGER no_audit_delete
  BEFORE DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION prevent_audit_modification();

-- ── updated_at AUTO-TRIGGER ─────────────────────────────────

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at BEFORE UPDATE ON candidates
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON truth_constraints
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON jobs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON applications
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
