"""
CareerPilot Agent 0 — Tests
Run: pytest tests/ -v
"""

import json
from datetime import date
from pathlib import Path
from unittest.mock import MagicMock, patch
from uuid import UUID, uuid4

import pytest

from agent0.models import (
    ParsedBullet,
    ParsedEducation,
    ParsedExperience,
    ParsedResume,
    ParsedSkill,
    TruthConstraints,
)
from agent0.parser import build_truth_constraints, parse_resume_with_claude


# ── Fixtures ─────────────────────────────────────────────────

SAMPLE_RESUME_JSON = {
    "name": "Priya Sharma",
    "email": "priya@example.com",
    "phone": "+1-571-555-0123",
    "location": "Herndon, VA",
    "linkedin": "https://linkedin.com/in/priyasharma",
    "github": "https://github.com/priyasharma",
    "portfolio": None,
    "summary": "Full-stack engineer with 4 years of experience in distributed systems.",
    "experiences": [
        {
            "company": "Amazon",
            "role": "Software Development Engineer II",
            "location": "Arlington, VA",
            "start_date": "2022-06-01",
            "end_date": None,
            "is_current": True,
            "bullets": [
                {
                    "text": "Designed and implemented a real-time inventory tracking system processing 2M events/day using Kafka and DynamoDB",
                    "skills": ["Kafka", "DynamoDB", "Java", "distributed systems"],
                    "quantified": True,
                    "action_verb": "Designed",
                },
                {
                    "text": "Reduced API latency by 40% through caching layer optimization with ElastiCache",
                    "skills": ["ElastiCache", "Redis", "performance optimization"],
                    "quantified": True,
                    "action_verb": "Reduced",
                },
            ],
            "skills": ["Java", "Kafka", "DynamoDB", "AWS", "Redis"],
        },
        {
            "company": "Deloitte",
            "role": "Software Engineer",
            "location": "McLean, VA",
            "start_date": "2020-08-01",
            "end_date": "2022-05-31",
            "is_current": False,
            "bullets": [
                {
                    "text": "Built microservices architecture serving 500K daily active users on Spring Boot and PostgreSQL",
                    "skills": ["Spring Boot", "PostgreSQL", "microservices"],
                    "quantified": True,
                    "action_verb": "Built",
                },
            ],
            "skills": ["Spring Boot", "PostgreSQL", "Java", "Docker"],
        },
    ],
    "education": [
        {
            "school": "Virginia Tech",
            "degree": "M.S.",
            "field_of_study": "Computer Science",
            "graduation_year": 2020,
            "gpa": 3.8,
        }
    ],
    "skills": [
        {"name": "Python", "proficiency": "advanced", "years": 3.0, "source": "resume"},
        {"name": "Java", "proficiency": "expert", "years": 4.0, "source": "resume"},
        {"name": "Kafka", "proficiency": "advanced", "years": 2.0, "source": "resume"},
        {"name": "AWS", "proficiency": "advanced", "years": 3.0, "source": "resume"},
        {"name": "PostgreSQL", "proficiency": "intermediate", "years": 2.0, "source": "resume"},
    ],
    "certifications": ["AWS Solutions Architect Associate"],
    "total_yoe": 4.5,
}


@pytest.fixture
def sample_resume() -> ParsedResume:
    return ParsedResume(**SAMPLE_RESUME_JSON)


# ── Model Tests ──────────────────────────────────────────────


class TestModels:
    def test_parsed_bullet_defaults(self):
        bullet = ParsedBullet(text="Built a thing")
        assert bullet.skills == []
        assert bullet.quantified is False
        assert bullet.action_verb is None

    def test_parsed_bullet_full(self):
        bullet = ParsedBullet(
            text="Reduced latency by 40%",
            skills=["Redis"],
            quantified=True,
            action_verb="Reduced",
        )
        assert bullet.quantified is True
        assert "Redis" in bullet.skills

    def test_parsed_experience_infers_current(self):
        exp = ParsedExperience(
            company="Google",
            role="SWE",
            start_date=date(2023, 1, 1),
            end_date=None,
        )
        assert exp.is_current is True

    def test_parsed_experience_not_current(self):
        exp = ParsedExperience(
            company="Google",
            role="SWE",
            start_date=date(2021, 1, 1),
            end_date=date(2023, 1, 1),
        )
        assert exp.is_current is False

    def test_parsed_resume_from_json(self, sample_resume):
        assert sample_resume.name == "Priya Sharma"
        assert len(sample_resume.experiences) == 2
        assert len(sample_resume.skills) == 5
        assert sample_resume.experiences[0].is_current is True
        assert sample_resume.total_yoe == 4.5

    def test_bullet_count(self, sample_resume):
        total = sum(len(e.bullets) for e in sample_resume.experiences)
        assert total == 3

    def test_truth_constraints(self, sample_resume):
        cid = uuid4()
        truth = build_truth_constraints(sample_resume, cid)
        assert truth.candidate_id == cid
        assert "Amazon" in truth.companies
        assert "Deloitte" in truth.companies
        assert truth.max_yoe == 4.5
        assert len(truth.date_ranges) == 2
        assert truth.date_ranges[0]["company"] == "Amazon"

    def test_skill_uniqueness(self, sample_resume):
        names = [s.name for s in sample_resume.skills]
        assert len(names) == len(set(names)), "Duplicate skill names"


# ── Parser Tests (mocked Claude calls) ──────────────────────


class TestParser:
    @patch("agent0.parser.anthropic.Anthropic")
    def test_parse_resume_success(self, mock_anthropic_cls, tmp_path):
        # Create a fake PDF file
        fake_pdf = tmp_path / "resume.pdf"
        fake_pdf.write_bytes(b"%PDF-1.4 fake content")

        # Mock Claude response
        mock_message = MagicMock()
        mock_message.content = [
            MagicMock(text=json.dumps(SAMPLE_RESUME_JSON))
        ]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_message
        mock_anthropic_cls.return_value = mock_client

        result = parse_resume_with_claude(fake_pdf)

        assert isinstance(result, ParsedResume)
        assert result.name == "Priya Sharma"
        assert len(result.experiences) == 2
        mock_client.messages.create.assert_called_once()

    @patch("agent0.parser.anthropic.Anthropic")
    def test_parse_resume_strips_markdown_fences(self, mock_anthropic_cls, tmp_path):
        fake_pdf = tmp_path / "resume.pdf"
        fake_pdf.write_bytes(b"%PDF-1.4 fake")

        # Claude sometimes wraps JSON in markdown fences
        fenced_json = f"```json\n{json.dumps(SAMPLE_RESUME_JSON)}\n```"
        mock_message = MagicMock()
        mock_message.content = [MagicMock(text=fenced_json)]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_message
        mock_anthropic_cls.return_value = mock_client

        result = parse_resume_with_claude(fake_pdf)
        assert result.name == "Priya Sharma"

    def test_parse_resume_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            parse_resume_with_claude(Path("/nonexistent/resume.pdf"))

    def test_parse_resume_wrong_extension(self, tmp_path):
        fake_file = tmp_path / "resume.docx"
        fake_file.write_bytes(b"not a pdf")
        with pytest.raises(ValueError, match="Expected a PDF"):
            parse_resume_with_claude(fake_file)

    def test_parse_resume_too_large(self, tmp_path):
        huge_pdf = tmp_path / "huge.pdf"
        huge_pdf.write_bytes(b"%PDF" + b"0" * (11 * 1024 * 1024))
        with pytest.raises(ValueError, match="too large"):
            parse_resume_with_claude(huge_pdf)

    @patch("agent0.parser.anthropic.Anthropic")
    def test_parse_resume_invalid_json(self, mock_anthropic_cls, tmp_path):
        fake_pdf = tmp_path / "resume.pdf"
        fake_pdf.write_bytes(b"%PDF-1.4 fake")

        mock_message = MagicMock()
        mock_message.content = [MagicMock(text="This is not JSON at all")]
        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_message
        mock_anthropic_cls.return_value = mock_client

        with pytest.raises(ValueError, match="invalid JSON"):
            parse_resume_with_claude(fake_pdf)


# ── DB Writer Tests (mocked PostgreSQL) ─────────────────────


class TestDBWriter:
    @patch("agent0.db_writer.get_pg_connection")
    def test_write_candidate_calls_insert(self, mock_get_conn, sample_resume):
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = (uuid4(),)
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_get_conn.return_value = mock_conn

        from agent0.db_writer import write_candidate

        user_id = uuid4()
        result = write_candidate(sample_resume, user_id)

        assert result is not None
        mock_conn.commit.assert_called_once()
        # Verify INSERT was called (candidate + experiences + skills + truth + audit)
        assert mock_cursor.execute.call_count >= 4


# ── Pinecone Writer Tests (mocked) ──────────────────────────


class TestPineconeWriter:
    @patch("agent0.pinecone_writer.openai.OpenAI")
    def test_generate_embeddings(self, mock_openai_cls):
        from agent0.pinecone_writer import generate_embeddings

        mock_embedding = MagicMock()
        mock_embedding.embedding = [0.1] * 1536

        mock_response = MagicMock()
        mock_response.data = [mock_embedding, mock_embedding]

        mock_client = MagicMock()
        mock_client.embeddings.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        result = generate_embeddings(["text1", "text2"])
        assert len(result) == 2
        assert len(result[0]) == 1536

    def test_build_bullet_records(self, sample_resume):
        from agent0.pinecone_writer import build_bullet_records

        cid = uuid4()

        with patch("agent0.pinecone_writer.generate_embeddings") as mock_embed:
            mock_embed.return_value = [[0.1] * 1536] * 3  # 3 bullets

            records = build_bullet_records(sample_resume, cid)

            assert len(records) == 3
            assert records[0]["metadata"]["company"] == "Amazon"
            assert records[0]["metadata"]["candidate_id"] == str(cid)
            assert len(records[0]["values"]) == 1536

    def test_build_bullet_records_empty_resume(self):
        from agent0.pinecone_writer import build_bullet_records

        empty = ParsedResume(name="Test", email="t@t.com", experiences=[])
        records = build_bullet_records(empty, uuid4())
        assert records == []
