"""
CareerPilot Agent 0 — Resume Parser
Uses Claude Sonnet to parse a resume PDF into structured JSON,
then writes to PostgreSQL/Supabase and upserts to Pinecone.

Usage:
    python -m agent0.parser /path/to/resume.pdf --user-id <uuid>
"""

import base64
import json
import logging
import sys
from pathlib import Path
from uuid import UUID

import anthropic

from agent0.models import (
    ParsedBullet,
    ParsedEducation,
    ParsedExperience,
    ParsedResume,
    ParsedSkill,
    TruthConstraints,
)

logger = logging.getLogger("agent0.parser")

# ── Prompt ───────────────────────────────────────────────────

SYSTEM_PROMPT = """\
You are an expert resume parser for CareerPilot, a job application platform \
for visa-sponsored candidates in the US.

Your task: extract ALL structured information from the resume PDF provided.

Return ONLY valid JSON matching this exact schema (no markdown fences, no commentary):

{
  "name": "string",
  "email": "string",
  "phone": "string or null",
  "location": "string or null",
  "linkedin": "string or null",
  "github": "string or null",
  "portfolio": "string or null",
  "summary": "string or null — professional summary if present",
  "experiences": [
    {
      "company": "string",
      "role": "string",
      "location": "string or null",
      "start_date": "YYYY-MM-DD (use first of month if only month given)",
      "end_date": "YYYY-MM-DD or null if current",
      "is_current": boolean,
      "bullets": [
        {
          "text": "exact bullet text",
          "skills": ["skill1", "skill2"],
          "quantified": true/false,
          "action_verb": "string or null"
        }
      ],
      "skills": ["aggregated skills from this role"]
    }
  ],
  "education": [
    {
      "school": "string",
      "degree": "string (e.g. B.S., M.S., Ph.D.)",
      "field_of_study": "string or null",
      "graduation_year": number or null,
      "gpa": number or null
    }
  ],
  "skills": [
    {
      "name": "string",
      "proficiency": "beginner|intermediate|advanced|expert",
      "years": number or null,
      "source": "resume"
    }
  ],
  "certifications": ["cert1", "cert2"],
  "total_yoe": number or null
}

Rules:
1. Extract EVERY bullet point verbatim — do not summarize or combine.
2. For each bullet, identify embedded skills (languages, frameworks, tools, methodologies).
3. Mark bullets as "quantified" if they contain numbers, percentages, dollar amounts, or metrics.
4. Extract the leading action verb from each bullet.
5. Infer proficiency from context (e.g. "5 years of Python" → expert, mentioned once → intermediate).
6. Calculate total_yoe from the span of all experiences (earliest start to latest end/now).
7. Normalize dates to ISO format. Use day=01 if only month/year given.
8. If visa status is mentioned anywhere, note it. Default to "f1_opt".
9. Return ONLY the JSON object — no markdown, no explanation.\
"""


def encode_pdf_to_base64(pdf_path: Path) -> str:
    """Read a PDF file and return base64-encoded content."""
    with open(pdf_path, "rb") as f:
        return base64.standard_b64encode(f.read()).decode("utf-8")


def parse_resume_with_claude(
    pdf_path: Path,
    *,
    api_key: str | None = None,
    model: str = "claude-sonnet-4-20250514",
    max_tokens: int = 8192,
) -> ParsedResume:
    """
    Send a resume PDF to Claude Sonnet and parse the structured JSON response.

    Args:
        pdf_path: Path to the resume PDF file.
        api_key: Anthropic API key. Falls back to ANTHROPIC_API_KEY env var.
        model: Claude model to use.
        max_tokens: Max response tokens.

    Returns:
        ParsedResume with all extracted information.

    Raises:
        FileNotFoundError: If PDF doesn't exist.
        ValueError: If Claude returns unparseable output.
        anthropic.APIError: On API failures.
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"Resume PDF not found: {pdf_path}")
    if not pdf_path.suffix.lower() == ".pdf":
        raise ValueError(f"Expected a PDF file, got: {pdf_path.suffix}")

    file_size_mb = pdf_path.stat().st_size / (1024 * 1024)
    if file_size_mb > 10:
        raise ValueError(f"PDF too large ({file_size_mb:.1f} MB). Max 10 MB.")

    logger.info(f"Parsing resume: {pdf_path.name} ({file_size_mb:.2f} MB)")

    # Encode PDF
    pdf_b64 = encode_pdf_to_base64(pdf_path)

    # Call Claude
    client = anthropic.Anthropic(api_key=api_key)

    message = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=SYSTEM_PROMPT,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "document",
                        "source": {
                            "type": "base64",
                            "media_type": "application/pdf",
                            "data": pdf_b64,
                        },
                    },
                    {
                        "type": "text",
                        "text": "Parse this resume into the structured JSON format specified in your instructions.",
                    },
                ],
            }
        ],
    )

    # Extract and parse JSON
    raw_text = message.content[0].text.strip()

    # Strip markdown fences if Claude adds them despite instructions
    if raw_text.startswith("```"):
        raw_text = raw_text.split("\n", 1)[1]
        if raw_text.endswith("```"):
            raw_text = raw_text[: raw_text.rfind("```")]
        raw_text = raw_text.strip()

    try:
        parsed_data = json.loads(raw_text)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse Claude response as JSON: {e}")
        logger.debug(f"Raw response: {raw_text[:500]}")
        raise ValueError(f"Claude returned invalid JSON: {e}") from e

    resume = ParsedResume(**parsed_data)

    logger.info(
        f"Parsed: {resume.name} | "
        f"{len(resume.experiences)} experiences | "
        f"{len(resume.skills)} skills | "
        f"{sum(len(e.bullets) for e in resume.experiences)} bullets"
    )

    return resume


def build_truth_constraints(
    resume: ParsedResume, candidate_id: UUID
) -> TruthConstraints:
    """
    Derive truth constraints from a parsed resume.
    Agent 3 (Architect) will cross-check every rewrite against these.
    """
    date_ranges = []
    for exp in resume.experiences:
        date_ranges.append(
            {
                "company": exp.company,
                "start": exp.start_date.isoformat(),
                "end": exp.end_date.isoformat() if exp.end_date else None,
            }
        )

    return TruthConstraints(
        candidate_id=candidate_id,
        companies=[e.company for e in resume.experiences],
        roles=[e.role for e in resume.experiences],
        date_ranges=date_ranges,
        skills=[s.name for s in resume.skills],
        degrees=[
            {
                "school": ed.school,
                "degree": ed.degree,
                "field": ed.field_of_study,
                "year": ed.graduation_year,
            }
            for ed in resume.education
        ],
        certifications=resume.certifications,
        max_yoe=resume.total_yoe,
    )
