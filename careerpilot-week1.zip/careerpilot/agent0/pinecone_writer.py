"""
CareerPilot Agent 0 — Pinecone Writer
Generates embeddings for resume bullets and upserts to Pinecone
in the 'profile-bullets' namespace.

Embedding model: text-embedding-3-small (1536 dims, $0.02/1M tokens)
"""

import logging
import os
from uuid import UUID

import openai
from pinecone import Pinecone, ServerlessSpec

from agent0.models import ParsedResume

logger = logging.getLogger("agent0.pinecone_writer")

# ── Config ───────────────────────────────────────────────────

EMBEDDING_MODEL = "text-embedding-3-small"
EMBEDDING_DIMS = 1536
NAMESPACE = "profile-bullets"
BATCH_SIZE = 100  # Pinecone upsert batch limit


def get_pinecone_client() -> Pinecone:
    """Initialize Pinecone client from env vars."""
    return Pinecone(api_key=os.getenv("PINECONE_API_KEY"))


def ensure_index(pc: Pinecone, index_name: str) -> None:
    """Create the Pinecone index if it doesn't exist."""
    existing = [idx.name for idx in pc.list_indexes()]
    if index_name not in existing:
        logger.info(f"Creating Pinecone index: {index_name}")
        pc.create_index(
            name=index_name,
            dimension=EMBEDDING_DIMS,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1"),
        )
        logger.info(f"Index '{index_name}' created")
    else:
        logger.info(f"Index '{index_name}' already exists")


def generate_embeddings(texts: list[str]) -> list[list[float]]:
    """
    Generate embeddings using OpenAI's text-embedding-3-small.
    Batches are handled by the OpenAI client.
    """
    client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    response = client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=texts,
    )

    return [item.embedding for item in response.data]


def build_bullet_records(
    resume: ParsedResume,
    candidate_id: UUID,
) -> list[dict]:
    """
    Build Pinecone upsert records from resume bullets.

    Each bullet gets its own vector with metadata for filtering:
    - candidate_id: for per-user namespace isolation
    - company: for company-specific matching
    - role: for role-specific matching
    - skills: for skill filtering
    - text: original bullet (stored for display, not searched)
    """
    records = []
    texts = []

    for exp_idx, exp in enumerate(resume.experiences):
        for bullet_idx, bullet in enumerate(exp.bullets):
            record_id = f"{candidate_id}_{exp_idx}_{bullet_idx}"

            # Enriched text for better semantic matching:
            # "Software Engineer at Google: Built distributed caching..."
            enriched_text = f"{exp.role} at {exp.company}: {bullet.text}"
            texts.append(enriched_text)

            records.append({
                "id": record_id,
                "metadata": {
                    "candidate_id": str(candidate_id),
                    "company": exp.company,
                    "role": exp.role,
                    "skills": bullet.skills,
                    "quantified": bullet.quantified,
                    "text": bullet.text[:500],  # Pinecone metadata limit
                    "exp_index": exp_idx,
                    "bullet_index": bullet_idx,
                },
            })

    if not texts:
        logger.warning("No bullets found in resume — skipping embedding")
        return []

    # Generate all embeddings in one batch
    logger.info(f"Generating embeddings for {len(texts)} bullets")
    embeddings = generate_embeddings(texts)

    for record, embedding in zip(records, embeddings):
        record["values"] = embedding

    return records


def upsert_to_pinecone(
    resume: ParsedResume,
    candidate_id: UUID,
    *,
    index_name: str | None = None,
) -> int:
    """
    Generate embeddings and upsert bullet vectors to Pinecone.

    Args:
        resume: Parsed resume data.
        candidate_id: UUID of the candidate.
        index_name: Pinecone index name. Defaults to PINECONE_INDEX_NAME env var.

    Returns:
        Number of vectors upserted.
    """
    index_name = index_name or os.getenv(
        "PINECONE_INDEX_NAME", "careerpilot-profiles"
    )

    pc = get_pinecone_client()
    ensure_index(pc, index_name)

    index = pc.Index(index_name)

    # Build records with embeddings
    records = build_bullet_records(resume, candidate_id)
    if not records:
        return 0

    # Delete existing vectors for this candidate (full replace)
    try:
        index.delete(
            filter={"candidate_id": {"$eq": str(candidate_id)}},
            namespace=NAMESPACE,
        )
        logger.info(f"Cleared existing vectors for candidate {candidate_id}")
    except Exception as e:
        # Index might be empty on first run
        logger.debug(f"Delete filter returned: {e}")

    # Batch upsert
    upserted = 0
    for i in range(0, len(records), BATCH_SIZE):
        batch = records[i : i + BATCH_SIZE]
        index.upsert(vectors=batch, namespace=NAMESPACE)
        upserted += len(batch)
        logger.info(f"Upserted batch {i // BATCH_SIZE + 1}: {len(batch)} vectors")

    logger.info(
        f"✅ Upserted {upserted} bullet embeddings to "
        f"'{index_name}/{NAMESPACE}'"
    )
    return upserted
