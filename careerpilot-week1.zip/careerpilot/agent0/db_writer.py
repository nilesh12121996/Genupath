"""
CareerPilot Agent 0 — Database Writer
Writes parsed resume data to PostgreSQL (local) or Supabase (staging).
Uses psycopg2 for direct PG, supabase-py when SUPABASE_URL is set.
"""

import json
import logging
import os
from uuid import UUID, uuid4

import psycopg2
from psycopg2.extras import execute_values, Json

from agent0.models import ParsedResume, TruthConstraints

logger = logging.getLogger("agent0.db_writer")


def get_pg_connection():
    """Create a PostgreSQL connection from env vars or Vault secrets."""
    return psycopg2.connect(
        host=os.getenv("PG_HOST", "localhost"),
        port=int(os.getenv("PG_PORT", "5432")),
        dbname=os.getenv("PG_DATABASE", "careerpilot"),
        user=os.getenv("PG_USER", "careerpilot"),
        password=os.getenv("PG_PASSWORD", "localdev123"),
    )


def write_candidate(
    resume: ParsedResume,
    user_id: UUID,
    *,
    conn=None,
) -> UUID:
    """
    Write the full parsed resume to PostgreSQL.
    Returns the candidate_id.

    Performs an upsert on candidates — if the user_id already exists,
    it updates the existing record and replaces experiences/skills.
    """
    should_close = conn is None
    if conn is None:
        conn = get_pg_connection()

    try:
        with conn.cursor() as cur:
            # ── Upsert candidate ─────────────────────────────
            candidate_id = uuid4()
            cur.execute(
                """
                INSERT INTO candidates (id, user_id, name, email, location, visa_status,
                                        phone, linkedin, github, portfolio)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (user_id) DO UPDATE SET
                    name = EXCLUDED.name,
                    email = EXCLUDED.email,
                    location = EXCLUDED.location,
                    visa_status = EXCLUDED.visa_status,
                    phone = EXCLUDED.phone,
                    linkedin = EXCLUDED.linkedin,
                    github = EXCLUDED.github,
                    portfolio = EXCLUDED.portfolio,
                    updated_at = NOW()
                RETURNING id
                """,
                (
                    candidate_id,
                    str(user_id),
                    resume.name,
                    resume.email,
                    resume.location,
                    resume.visa_status,
                    resume.phone,
                    resume.linkedin,
                    resume.github,
                    resume.portfolio,
                ),
            )
            candidate_id = cur.fetchone()[0]
            logger.info(f"Upserted candidate: {candidate_id}")

            # ── Clear old experiences and skills (full replace) ──
            cur.execute(
                "DELETE FROM experiences WHERE candidate_id = %s",
                (str(candidate_id),),
            )
            cur.execute(
                "DELETE FROM skills WHERE candidate_id = %s",
                (str(candidate_id),),
            )

            # ── Insert experiences ───────────────────────────
            if resume.experiences:
                exp_rows = []
                for exp in resume.experiences:
                    exp_rows.append((
                        str(uuid4()),
                        str(candidate_id),
                        exp.company,
                        exp.role,
                        exp.start_date,
                        exp.end_date,
                        [b.text for b in exp.bullets],
                        exp.skills,
                        exp.is_current,
                        exp.location,
                    ))
                execute_values(
                    cur,
                    """
                    INSERT INTO experiences
                        (id, candidate_id, company, role, start_date, end_date,
                         bullets, skills, is_current, location)
                    VALUES %s
                    """,
                    exp_rows,
                    template=(
                        "(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                    ),
                )
                logger.info(f"Inserted {len(exp_rows)} experiences")

            # ── Insert skills ────────────────────────────────
            if resume.skills:
                skill_rows = []
                for skill in resume.skills:
                    skill_rows.append((
                        str(uuid4()),
                        str(candidate_id),
                        skill.name,
                        skill.proficiency,
                        skill.years,
                        skill.source,
                    ))
                execute_values(
                    cur,
                    """
                    INSERT INTO skills
                        (id, candidate_id, skill_name, proficiency, years, source)
                    VALUES %s
                    ON CONFLICT (candidate_id, skill_name) DO UPDATE SET
                        proficiency = EXCLUDED.proficiency,
                        years = EXCLUDED.years
                    """,
                    skill_rows,
                    template="(%s, %s, %s, %s, %s, %s)",
                )
                logger.info(f"Inserted {len(skill_rows)} skills")

            # ── Insert truth constraints ─────────────────────
            truth = _build_truth(resume, candidate_id)
            cur.execute(
                """
                INSERT INTO truth_constraints
                    (id, candidate_id, companies, roles, date_ranges,
                     skills, degrees, certifications, max_yoe)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT ON CONSTRAINT truth_constraints_pkey DO NOTHING
                """,
                (
                    str(uuid4()),
                    str(candidate_id),
                    truth.companies,
                    truth.roles,
                    Json(truth.date_ranges),
                    truth.skills,
                    Json(truth.degrees),
                    truth.certifications,
                    truth.max_yoe,
                ),
            )
            # Delete old and re-insert if exists
            cur.execute(
                """
                DELETE FROM truth_constraints
                WHERE candidate_id = %s
                  AND id != (
                    SELECT id FROM truth_constraints
                    WHERE candidate_id = %s
                    ORDER BY created_at DESC LIMIT 1
                  )
                """,
                (str(candidate_id), str(candidate_id)),
            )
            logger.info("Wrote truth constraints")

            # ── Audit log ────────────────────────────────────
            cur.execute(
                """
                INSERT INTO audit_log (user_id, action, entity, entity_id, details)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (
                    str(user_id),
                    "resume_parsed",
                    "candidate",
                    str(candidate_id),
                    Json({
                        "experiences_count": len(resume.experiences),
                        "skills_count": len(resume.skills),
                        "bullets_count": sum(
                            len(e.bullets) for e in resume.experiences
                        ),
                    }),
                ),
            )

            conn.commit()
            logger.info(f"✅ All data committed for candidate {candidate_id}")
            return candidate_id

    except Exception:
        conn.rollback()
        logger.exception("Failed to write candidate data")
        raise
    finally:
        if should_close:
            conn.close()


def _build_truth(resume: ParsedResume, candidate_id: UUID) -> TruthConstraints:
    """Build truth constraints from parsed resume."""
    date_ranges = []
    for exp in resume.experiences:
        date_ranges.append({
            "company": exp.company,
            "start": exp.start_date.isoformat(),
            "end": exp.end_date.isoformat() if exp.end_date else None,
        })

    return TruthConstraints(
        candidate_id=candidate_id,
        companies=[e.company for e in resume.experiences],
        roles=[e.role for e in resume.experiences],
        date_ranges=date_ranges,
        skills=[s.name for s in resume.skills],
        degrees=[
            {
                "school": ed.school,
                "degree": ed.degree,
                "field": ed.field_of_study,
                "year": ed.graduation_year,
            }
            for ed in resume.education
        ],
        certifications=resume.certifications,
        max_yoe=resume.total_yoe,
    )
