"""
CareerPilot Agent 0 — Data Models
Pydantic v2 models for resume parsing pipeline.
"""

from datetime import date, datetime
from typing import Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, field_validator


class ParsedBullet(BaseModel):
    """A single resume bullet point with extracted metadata."""
    text: str
    skills: list[str] = Field(default_factory=list)
    quantified: bool = False          # contains numbers/metrics
    action_verb: str | None = None    # leading action verb


class ParsedExperience(BaseModel):
    """A single work experience entry."""
    company: str
    role: str
    location: str | None = None
    start_date: date
    end_date: date | None = None      # None = current
    is_current: bool = False
    bullets: list[ParsedBullet] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)

    @field_validator("is_current", mode="before")
    @classmethod
    def infer_current(cls, v, info):
        if info.data.get("end_date") is None:
            return True
        return v


class ParsedEducation(BaseModel):
    """Education entry."""
    school: str
    degree: str
    field_of_study: str | None = None
    graduation_year: int | None = None
    gpa: float | None = None


class ParsedSkill(BaseModel):
    """Extracted skill with optional proficiency."""
    name: str
    proficiency: str = "intermediate"  # beginner|intermediate|advanced|expert
    years: float | None = None
    source: str = "resume"


class ParsedResume(BaseModel):
    """Complete structured resume output from Claude Sonnet parsing."""
    name: str
    email: str
    phone: str | None = None
    location: str | None = None
    linkedin: str | None = None
    github: str | None = None
    portfolio: str | None = None
    visa_status: str = "f1_opt"
    summary: str | None = None
    experiences: list[ParsedExperience] = Field(default_factory=list)
    education: list[ParsedEducation] = Field(default_factory=list)
    skills: list[ParsedSkill] = Field(default_factory=list)
    certifications: list[str] = Field(default_factory=list)
    total_yoe: float | None = None    # total years of experience


class TruthConstraints(BaseModel):
    """Ground truth derived from the parsed resume.
    Every AI rewrite must stay within these bounds."""
    candidate_id: UUID
    companies: list[str]
    roles: list[str]
    date_ranges: list[dict]           # [{company, start, end}]
    skills: list[str]
    degrees: list[dict]               # [{school, degree, field, year}]
    certifications: list[str]
    max_yoe: float | None = None


class EmbeddingRecord(BaseModel):
    """A bullet embedding destined for Pinecone."""
    id: str                           # {candidate_id}_{experience_idx}_{bullet_idx}
    values: list[float]               # 1536-dim embedding vector
    metadata: dict                    # company, role, skills, text snippet
