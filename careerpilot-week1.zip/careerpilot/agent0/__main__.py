"""
CareerPilot Agent 0 — Intake Pipeline
Main entry point: parse resume → write DB → upsert Pinecone.

Usage:
    python -m agent0 /path/to/resume.pdf --user-id <uuid>
    python -m agent0 /path/to/resume.pdf --user-id <uuid> --skip-pinecone
"""

import argparse
import logging
import sys
import time
from pathlib import Path
from uuid import UUID

from agent0.parser import parse_resume_with_claude
from agent0.db_writer import write_candidate
from agent0.pinecone_writer import upsert_to_pinecone

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("agent0")


def run_intake(
    pdf_path: str,
    user_id: str,
    *,
    skip_pinecone: bool = False,
    skip_db: bool = False,
) -> dict:
    """
    Full intake pipeline:
      1. Parse resume PDF with Claude Sonnet → ParsedResume
      2. Write candidate + experiences + skills + truth_constraints to PostgreSQL
      3. Generate bullet embeddings → upsert to Pinecone (profile-bullets namespace)

    Returns:
        Summary dict with candidate_id, counts, and timing.
    """
    t0 = time.time()
    pdf = Path(pdf_path)

    # ── Step 1: Parse with Claude ────────────────────────────
    logger.info("=" * 60)
    logger.info("STEP 1: Parsing resume with Claude Sonnet")
    logger.info("=" * 60)

    t1 = time.time()
    resume = parse_resume_with_claude(pdf)
    parse_time = time.time() - t1

    logger.info(f"Parse complete in {parse_time:.1f}s")
    logger.info(f"  Name: {resume.name}")
    logger.info(f"  Email: {resume.email}")
    logger.info(f"  Experiences: {len(resume.experiences)}")
    logger.info(f"  Skills: {len(resume.skills)}")
    logger.info(
        f"  Total bullets: {sum(len(e.bullets) for e in resume.experiences)}"
    )

    candidate_id = None
    vectors_upserted = 0

    # ── Step 2: Write to PostgreSQL ──────────────────────────
    if not skip_db:
        logger.info("=" * 60)
        logger.info("STEP 2: Writing to PostgreSQL")
        logger.info("=" * 60)

        t2 = time.time()
        candidate_id = write_candidate(resume, UUID(user_id))
        db_time = time.time() - t2
        logger.info(f"DB write complete in {db_time:.1f}s → {candidate_id}")
    else:
        logger.info("STEP 2: Skipped (--skip-db)")

    # ── Step 3: Upsert to Pinecone ───────────────────────────
    if not skip_pinecone and candidate_id:
        logger.info("=" * 60)
        logger.info("STEP 3: Upserting embeddings to Pinecone")
        logger.info("=" * 60)

        t3 = time.time()
        vectors_upserted = upsert_to_pinecone(resume, candidate_id)
        pinecone_time = time.time() - t3
        logger.info(f"Pinecone upsert complete in {pinecone_time:.1f}s")
    else:
        logger.info("STEP 3: Skipped (--skip-pinecone or no candidate_id)")

    total_time = time.time() - t0

    summary = {
        "candidate_id": str(candidate_id) if candidate_id else None,
        "name": resume.name,
        "experiences": len(resume.experiences),
        "skills": len(resume.skills),
        "bullets": sum(len(e.bullets) for e in resume.experiences),
        "vectors_upserted": vectors_upserted,
        "total_time_s": round(total_time, 2),
    }

    logger.info("=" * 60)
    logger.info("INTAKE COMPLETE")
    for k, v in summary.items():
        logger.info(f"  {k}: {v}")
    logger.info("=" * 60)

    return summary


def main():
    parser = argparse.ArgumentParser(
        description="CareerPilot Agent 0 — Resume Intake",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Full pipeline (parse + DB + Pinecone)
  python -m agent0 resume.pdf --user-id 550e8400-e29b-41d4-a716-446655440000

  # Parse + DB only (skip Pinecone for local dev)
  python -m agent0 resume.pdf --user-id 550e8400-e29b-41d4-a716-446655440000 --skip-pinecone

  # Parse only (dry run, no writes)
  python -m agent0 resume.pdf --user-id 550e8400-e29b-41d4-a716-446655440000 --skip-db --skip-pinecone

Environment variables:
  ANTHROPIC_API_KEY     Claude API key (required)
  PG_HOST               PostgreSQL host (default: localhost)
  PG_PORT               PostgreSQL port (default: 5432)
  PG_DATABASE           Database name (default: careerpilot)
  PG_USER               DB user (default: careerpilot)
  PG_PASSWORD           DB password (default: localdev123)
  PINECONE_API_KEY      Pinecone API key
  PINECONE_INDEX_NAME   Index name (default: careerpilot-profiles)
  OPENAI_API_KEY        OpenAI key for embeddings
        """,
    )
    parser.add_argument("pdf_path", help="Path to the resume PDF")
    parser.add_argument(
        "--user-id",
        required=True,
        help="Supabase Auth user UUID",
    )
    parser.add_argument(
        "--skip-pinecone",
        action="store_true",
        help="Skip Pinecone upsert (local dev without Pinecone)",
    )
    parser.add_argument(
        "--skip-db",
        action="store_true",
        help="Skip database write (dry run / parse only)",
    )

    args = parser.parse_args()

    try:
        summary = run_intake(
            args.pdf_path,
            args.user_id,
            skip_pinecone=args.skip_pinecone,
            skip_db=args.skip_db,
        )
        sys.exit(0)
    except FileNotFoundError as e:
        logger.error(str(e))
        sys.exit(1)
    except ValueError as e:
        logger.error(f"Validation error: {e}")
        sys.exit(2)
    except Exception:
        logger.exception("Intake pipeline failed")
        sys.exit(3)


if __name__ == "__main__":
    main()
