# ──────────────────────────────────────────────────────────────
# Variables — populate via terraform.tfvars or CI env vars
# ──────────────────────────────────────────────────────────────

# ── General ──────────────────────────────────────────────────

variable "environment" {
  description = "Deployment environment"
  type        = string
  default     = "staging"
  validation {
    condition     = contains(["staging", "production"], var.environment)
    error_message = "Environment must be staging or production."
  }
}

variable "aws_region" {
  description = "AWS region for all resources"
  type        = string
  default     = "us-east-1"
}

# ── Confluent Cloud ─────────────────────────────────────────

variable "confluent_cloud_api_key" {
  description = "Confluent Cloud API key"
  type        = string
  sensitive   = true
}

variable "confluent_cloud_api_secret" {
  description = "Confluent Cloud API secret"
  type        = string
  sensitive   = true
}

variable "confluent_environment_id" {
  description = "Existing Confluent Cloud environment ID (e.g. env-xxxxx)"
  type        = string
}

# ── Cloudflare ───────────────────────────────────────────────

variable "cloudflare_api_token" {
  description = "Cloudflare API token with R2 permissions"
  type        = string
  sensitive   = true
}

variable "cloudflare_account_id" {
  description = "Cloudflare account ID"
  type        = string
}

# ── AWS Lambda (Agent 1 Scout cron) ─────────────────────────

variable "scout_schedule_expression" {
  description = "EventBridge cron for Scout agent"
  type        = string
  default     = "rate(30 minutes)"
}

variable "scout_lambda_memory" {
  description = "Lambda memory in MB"
  type        = number
  default     = 512
}

variable "scout_lambda_timeout" {
  description = "Lambda timeout in seconds"
  type        = number
  default     = 120
}
