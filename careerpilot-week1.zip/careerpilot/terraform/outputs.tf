# ──────────────────────────────────────────────────────────────
# Outputs — consumed by docker-compose .env and CI/CD
# ──────────────────────────────────────────────────────────────

# ── Kafka ────────────────────────────────────────────────────

output "kafka_bootstrap_servers" {
  description = "Confluent Cloud Kafka bootstrap servers"
  value       = confluent_kafka_cluster.main.bootstrap_endpoint
}

output "kafka_cluster_id" {
  description = "Kafka cluster ID"
  value       = confluent_kafka_cluster.main.id
}

output "kafka_rest_endpoint" {
  description = "Kafka REST endpoint"
  value       = confluent_kafka_cluster.main.rest_endpoint
}

output "scout_api_key" {
  description = "Scout producer API key ID"
  value       = confluent_api_key.scout_producer.id
  sensitive   = true
}

output "pipeline_api_key" {
  description = "Pipeline processor API key ID"
  value       = confluent_api_key.pipeline_processor.id
  sensitive   = true
}

# ── AWS ──────────────────────────────────────────────────────

output "scout_lambda_arn" {
  description = "Scout Lambda function ARN"
  value       = aws_lambda_function.scout.arn
}

output "scout_lambda_name" {
  description = "Scout Lambda function name"
  value       = aws_lambda_function.scout.function_name
}

# ── R2 ───────────────────────────────────────────────────────

output "r2_bucket_name" {
  description = "Cloudflare R2 bucket name"
  value       = cloudflare_r2_bucket.resumes.name
}
