# ──────────────────────────────────────────────────────────────
# Cloudflare R2 — Resume storage bucket
# Stores: original resume PDFs, AI-tailored LaTeX PDFs,
#         resume version snapshots
# ──────────────────────────────────────────────────────────────

resource "cloudflare_r2_bucket" "resumes" {
  account_id = var.cloudflare_account_id
  name       = "careerpilot-resumes-${var.environment}"
  location   = "ENAM" # Eastern North America — closest to us-east-1
}

# Lifecycle rule: move original uploads to Infrequent Access
# after 30 days, delete rejected drafts after 7 days
# (R2 lifecycle rules are set via the dashboard or API —
# Terraform support is limited, so we document intent here)
#
# Bucket structure:
#   originals/{candidate_id}/{upload_timestamp}.pdf
#   tailored/{candidate_id}/{job_id}/{version}.pdf
#   latex/{candidate_id}/{job_id}/{version}.tex
