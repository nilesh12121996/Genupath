# ──────────────────────────────────────────────────────────────
# Confluent Cloud — Kafka Cluster + Topics + ACLs
# Topics: jobs.raw → jobs.structured → jobs.matched →
#         jobs.rejected, applications.submitted
# ──────────────────────────────────────────────────────────────

# ── Reference existing environment ───────────────────────────

data "confluent_environment" "careerpilot" {
  id = var.confluent_environment_id
}

# ── Kafka Cluster (Basic tier for MVP — upgrade to Standard
#    when you need multi-zone or >100 MB/s) ───────────────────

resource "confluent_kafka_cluster" "main" {
  display_name = "careerpilot-${var.environment}"
  availability = "SINGLE_ZONE"
  cloud        = "AWS"
  region       = var.aws_region

  basic {}

  environment {
    id = data.confluent_environment.careerpilot.id
  }

  lifecycle {
    prevent_destroy = true
  }
}

# ── Service Accounts ─────────────────────────────────────────

resource "confluent_service_account" "scout_producer" {
  display_name = "scout-producer-${var.environment}"
  description  = "Agent 1 Scout — writes to jobs.raw"
}

resource "confluent_service_account" "pipeline_processor" {
  display_name = "pipeline-processor-${var.environment}"
  description  = "Agents 2-4 — reads/writes across pipeline topics"
}

resource "confluent_service_account" "notifier_consumer" {
  display_name = "notifier-consumer-${var.environment}"
  description  = "Agent 5 Notifier — reads from jobs.matched + applications.submitted"
}

# ── API Keys for service accounts ────────────────────────────

resource "confluent_api_key" "scout_producer" {
  display_name = "scout-producer-key"
  description  = "API key for Scout agent"

  owner {
    id          = confluent_service_account.scout_producer.id
    api_version = confluent_service_account.scout_producer.api_version
    kind        = confluent_service_account.scout_producer.kind
  }

  managed_resource {
    id          = confluent_kafka_cluster.main.id
    api_version = confluent_kafka_cluster.main.api_version
    kind        = confluent_kafka_cluster.main.kind

    environment {
      id = data.confluent_environment.careerpilot.id
    }
  }
}

resource "confluent_api_key" "pipeline_processor" {
  display_name = "pipeline-processor-key"
  description  = "API key for pipeline agents"

  owner {
    id          = confluent_service_account.pipeline_processor.id
    api_version = confluent_service_account.pipeline_processor.api_version
    kind        = confluent_service_account.pipeline_processor.kind
  }

  managed_resource {
    id          = confluent_kafka_cluster.main.id
    api_version = confluent_kafka_cluster.main.api_version
    kind        = confluent_kafka_cluster.main.kind

    environment {
      id = data.confluent_environment.careerpilot.id
    }
  }
}

resource "confluent_api_key" "notifier_consumer" {
  display_name = "notifier-consumer-key"
  description  = "API key for Notifier agent"

  owner {
    id          = confluent_service_account.notifier_consumer.id
    api_version = confluent_service_account.notifier_consumer.api_version
    kind        = confluent_service_account.notifier_consumer.kind
  }

  managed_resource {
    id          = confluent_kafka_cluster.main.id
    api_version = confluent_kafka_cluster.main.api_version
    kind        = confluent_kafka_cluster.main.kind

    environment {
      id = data.confluent_environment.careerpilot.id
    }
  }
}

# ── Topics ───────────────────────────────────────────────────
# Partition counts tuned for MVP throughput:
#   jobs.raw          — 3 partitions (Scout writes ~100 jobs/batch)
#   jobs.structured   — 3 partitions (GPT-4o-mini parsing)
#   jobs.matched      — 6 partitions (fan-out to Architect + Notifier)
#   jobs.rejected     — 1 partition  (cold path, low volume)
#   applications.submitted — 3 partitions (audit + Notifier)

resource "confluent_kafka_topic" "jobs_raw" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  topic_name       = "jobs.raw"
  partitions_count = 3
  rest_endpoint    = confluent_kafka_cluster.main.rest_endpoint

  config = {
    "cleanup.policy"  = "delete"
    "retention.ms"    = "604800000" # 7 days
    "max.message.bytes" = "1048576" # 1 MB — raw JD HTML can be large
  }

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

resource "confluent_kafka_topic" "jobs_structured" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  topic_name       = "jobs.structured"
  partitions_count = 3
  rest_endpoint    = confluent_kafka_cluster.main.rest_endpoint

  config = {
    "cleanup.policy" = "delete"
    "retention.ms"   = "604800000"
  }

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

resource "confluent_kafka_topic" "jobs_matched" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  topic_name       = "jobs.matched"
  partitions_count = 6
  rest_endpoint    = confluent_kafka_cluster.main.rest_endpoint

  config = {
    "cleanup.policy" = "delete"
    "retention.ms"   = "2592000000" # 30 days — matched jobs stay longer
  }

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

resource "confluent_kafka_topic" "jobs_rejected" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  topic_name       = "jobs.rejected"
  partitions_count = 1
  rest_endpoint    = confluent_kafka_cluster.main.rest_endpoint

  config = {
    "cleanup.policy" = "delete"
    "retention.ms"   = "259200000" # 3 days — short retention for rejects
  }

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

resource "confluent_kafka_topic" "applications_submitted" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  topic_name       = "applications.submitted"
  partitions_count = 3
  rest_endpoint    = confluent_kafka_cluster.main.rest_endpoint

  config = {
    "cleanup.policy" = "delete"
    "retention.ms"   = "7776000000" # 90 days — audit trail
  }

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

# ── ACLs — least privilege per agent ─────────────────────────

# Scout: WRITE to jobs.raw only
resource "confluent_kafka_acl" "scout_write_jobs_raw" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  resource_type = "TOPIC"
  resource_name = "jobs.raw"
  pattern_type  = "LITERAL"
  principal     = "User:${confluent_service_account.scout_producer.id}"
  host          = "*"
  operation     = "WRITE"
  permission    = "ALLOW"
  rest_endpoint = confluent_kafka_cluster.main.rest_endpoint

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

# Pipeline processor: READ/WRITE on all jobs.* and applications.*
resource "confluent_kafka_acl" "pipeline_readwrite_jobs" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  resource_type = "TOPIC"
  resource_name = "jobs."
  pattern_type  = "PREFIXED"
  principal     = "User:${confluent_service_account.pipeline_processor.id}"
  host          = "*"
  operation     = "READ"
  permission    = "ALLOW"
  rest_endpoint = confluent_kafka_cluster.main.rest_endpoint

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

resource "confluent_kafka_acl" "pipeline_write_jobs" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  resource_type = "TOPIC"
  resource_name = "jobs."
  pattern_type  = "PREFIXED"
  principal     = "User:${confluent_service_account.pipeline_processor.id}"
  host          = "*"
  operation     = "WRITE"
  permission    = "ALLOW"
  rest_endpoint = confluent_kafka_cluster.main.rest_endpoint

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

resource "confluent_kafka_acl" "pipeline_write_applications" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  resource_type = "TOPIC"
  resource_name = "applications."
  pattern_type  = "PREFIXED"
  principal     = "User:${confluent_service_account.pipeline_processor.id}"
  host          = "*"
  operation     = "WRITE"
  permission    = "ALLOW"
  rest_endpoint = confluent_kafka_cluster.main.rest_endpoint

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

# Pipeline processor: consumer group access
resource "confluent_kafka_acl" "pipeline_consumer_group" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  resource_type = "GROUP"
  resource_name = "careerpilot-pipeline"
  pattern_type  = "PREFIXED"
  principal     = "User:${confluent_service_account.pipeline_processor.id}"
  host          = "*"
  operation     = "READ"
  permission    = "ALLOW"
  rest_endpoint = confluent_kafka_cluster.main.rest_endpoint

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

# Notifier: READ on matched + submitted only
resource "confluent_kafka_acl" "notifier_read_matched" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  resource_type = "TOPIC"
  resource_name = "jobs.matched"
  pattern_type  = "LITERAL"
  principal     = "User:${confluent_service_account.notifier_consumer.id}"
  host          = "*"
  operation     = "READ"
  permission    = "ALLOW"
  rest_endpoint = confluent_kafka_cluster.main.rest_endpoint

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

resource "confluent_kafka_acl" "notifier_read_applications" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  resource_type = "TOPIC"
  resource_name = "applications.submitted"
  pattern_type  = "LITERAL"
  principal     = "User:${confluent_service_account.notifier_consumer.id}"
  host          = "*"
  operation     = "READ"
  permission    = "ALLOW"
  rest_endpoint = confluent_kafka_cluster.main.rest_endpoint

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}

resource "confluent_kafka_acl" "notifier_consumer_group" {
  kafka_cluster {
    id = confluent_kafka_cluster.main.id
  }

  resource_type = "GROUP"
  resource_name = "careerpilot-notifier"
  pattern_type  = "PREFIXED"
  principal     = "User:${confluent_service_account.notifier_consumer.id}"
  host          = "*"
  operation     = "READ"
  permission    = "ALLOW"
  rest_endpoint = confluent_kafka_cluster.main.rest_endpoint

  credentials {
    key    = confluent_api_key.pipeline_processor.id
    secret = confluent_api_key.pipeline_processor.secret
  }
}
