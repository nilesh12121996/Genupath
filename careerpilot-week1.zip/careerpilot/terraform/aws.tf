# ──────────────────────────────────────────────────────────────
# AWS — Lambda (Scout Agent) + EventBridge Cron
# Scout runs every 30 min, pulls from Greenhouse/Lever/Ashby
# public APIs, writes to Kafka jobs.raw
# ──────────────────────────────────────────────────────────────

# ── IAM Role for Lambda ──────────────────────────────────────

data "aws_iam_policy_document" "lambda_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "scout_lambda" {
  name               = "careerpilot-scout-${var.environment}"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
}

# CloudWatch Logs permission
resource "aws_iam_role_policy_attachment" "scout_logs" {
  role       = aws_iam_role.scout_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

# Secrets Manager access (for Kafka creds + API keys)
data "aws_iam_policy_document" "scout_secrets" {
  statement {
    actions = [
      "secretsmanager:GetSecretValue",
    ]
    resources = [
      "arn:aws:secretsmanager:${var.aws_region}:*:secret:careerpilot/scout/*",
    ]
  }
}

resource "aws_iam_role_policy" "scout_secrets" {
  name   = "scout-secrets-access"
  role   = aws_iam_role.scout_lambda.id
  policy = data.aws_iam_policy_document.scout_secrets.json
}

# ── Lambda Function ──────────────────────────────────────────
# Placeholder — actual code deployed via CI in Week 2
# For now we create the function shell with a dummy handler

resource "aws_lambda_function" "scout" {
  function_name = "careerpilot-scout-${var.environment}"
  role          = aws_iam_role.scout_lambda.arn
  handler       = "handler.lambda_handler"
  runtime       = "python3.12"
  memory_size   = var.scout_lambda_memory
  timeout       = var.scout_lambda_timeout
  architectures = ["arm64"] # Graviton2 — cheaper + faster for Python

  # Placeholder zip — replaced by CI deploy in Week 2
  filename         = "${path.module}/lambda_placeholder.zip"
  source_code_hash = filebase64sha256("${path.module}/lambda_placeholder.zip")

  environment {
    variables = {
      ENVIRONMENT         = var.environment
      KAFKA_TOPIC         = "jobs.raw"
      # Actual secrets fetched from Secrets Manager at runtime
      SECRETS_PREFIX      = "careerpilot/scout"
    }
  }

  tags = {
    Agent = "scout"
  }
}

# ── EventBridge Rule (Cron) ──────────────────────────────────

resource "aws_cloudwatch_event_rule" "scout_schedule" {
  name                = "careerpilot-scout-cron-${var.environment}"
  description         = "Trigger Scout agent on schedule"
  schedule_expression = var.scout_schedule_expression
  state               = "ENABLED"
}

resource "aws_cloudwatch_event_target" "scout_lambda" {
  rule = aws_cloudwatch_event_rule.scout_schedule.name
  arn  = aws_lambda_function.scout.arn
}

resource "aws_lambda_permission" "allow_eventbridge" {
  statement_id  = "AllowEventBridgeInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.scout.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.scout_schedule.arn
}
