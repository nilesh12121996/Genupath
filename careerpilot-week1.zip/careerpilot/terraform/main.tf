# ──────────────────────────────────────────────────────────────
# CareerPilot 2026 — Terraform Root
# Providers: AWS, Confluent Cloud, Cloudflare (R2)
# Region: us-east-1 | Backend: S3 (swap to local for first run)
# ──────────────────────────────────────────────────────────────

terraform {
  required_version = ">= 1.7.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
    confluent = {
      source  = "confluentinc/confluent"
      version = "~> 2.4"
    }
    cloudflare = {
      source  = "cloudflare/cloudflare"
      version = "~> 4.30"
    }
  }

  # Uncomment after first apply to migrate state to S3
  # backend "s3" {
  #   bucket         = "careerpilot-tfstate"
  #   key            = "infra/terraform.tfstate"
  #   region         = "us-east-1"
  #   dynamodb_table = "careerpilot-tflock"
  #   encrypt        = true
  # }
}

# ── Providers ────────────────────────────────────────────────

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "careerpilot"
      Environment = var.environment
      ManagedBy   = "terraform"
    }
  }
}

provider "confluent" {
  cloud_api_key    = var.confluent_cloud_api_key
  cloud_api_secret = var.confluent_cloud_api_secret
}

provider "cloudflare" {
  api_token = var.cloudflare_api_token
}
