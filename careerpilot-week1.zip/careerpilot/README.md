# CareerPilot 2026 — Week 1

AI-powered job application platform for F1/OPT/H4 visa candidates in the US.

## Week 1 Deliverables

| Component | Description |
|-----------|-------------|
| `terraform/` | Confluent Cloud Kafka (5 topics + ACLs), AWS Lambda + EventBridge (Scout cron), Cloudflare R2 bucket |
| `docker-compose.yml` | Full Confluent Platform (broker, Schema Registry, Connect, ksqlDB, Control Center) + PostgreSQL 16 + Vault (dev mode) + Redis |
| `db/schema.sql` | 8 tables with RLS, enums, indexes, immutable audit log, auto-updated timestamps |
| `agent0/` | Resume intake pipeline: Claude Sonnet parser → PostgreSQL writer → Pinecone embeddings |
| `tests/` | Unit tests with mocked Claude/Pinecone/PostgreSQL calls |

## Quick Start

### Prerequisites

- Docker Desktop (or compatible runtime)
- Python 3.11+
- Terraform 1.7+ (for cloud provisioning)
- API keys: Anthropic, OpenAI, Pinecone

### 1. Start Local Dev Environment

```bash
# Clone and enter project
cd careerpilot

# Start all services
./scripts/dev-up.sh

# Verify schema
python scripts/validate_schema.py
```

Services available after startup:

| Service | URL |
|---------|-----|
| PostgreSQL | `localhost:5432` (careerpilot/localdev123) |
| Kafka Broker | `localhost:9092` |
| Schema Registry | `http://localhost:8081` |
| Kafka Connect | `http://localhost:8083` |
| ksqlDB | `http://localhost:8088` |
| Control Center | `http://localhost:9021` |
| Vault | `http://localhost:8200` (token: `root`) |
| Redis | `localhost:6379` |
| Redis Commander | `http://localhost:8082` |

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your API keys
```

### 3. Install Agent 0 Dependencies

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r agent0/requirements.txt
```

### 4. Run Agent 0 (Resume Intake)

```bash
# Full pipeline (parse + DB + Pinecone)
python -m agent0 /path/to/resume.pdf \
  --user-id 550e8400-e29b-41d4-a716-446655440000

# Local dev (skip Pinecone)
python -m agent0 /path/to/resume.pdf \
  --user-id 550e8400-e29b-41d4-a716-446655440000 \
  --skip-pinecone

# Dry run (parse only)
python -m agent0 /path/to/resume.pdf \
  --user-id 550e8400-e29b-41d4-a716-446655440000 \
  --skip-db --skip-pinecone
```

### 5. Run Tests

```bash
pip install pytest
pytest tests/ -v
```

### 6. Provision Cloud Infrastructure

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
# Fill in credentials

terraform init
terraform plan
terraform apply
```

## Architecture (Week 1)

```
Resume PDF
    │
    ▼
┌──────────────────────┐
│  Agent 0: Intake     │
│  (Claude Sonnet)     │
│  Parse → JSON        │
└──────┬───────────────┘
       │
       ├──────────────────────► PostgreSQL
       │                        • candidates
       │                        • experiences
       │                        • skills
       │                        • truth_constraints
       │                        • audit_log
       │
       └──────────────────────► Pinecone
                                • profile-bullets namespace
                                • 1536-dim embeddings
                                • metadata: company, role, skills
```

## Kafka Topics

| Topic | Partitions | Retention | Purpose |
|-------|-----------|-----------|---------|
| `jobs.raw` | 3 | 7 days | Raw JD HTML from Scout |
| `jobs.structured` | 3 | 7 days | Parsed JD JSON |
| `jobs.matched` | 6 | 30 days | Matched jobs (passed H1B gate) |
| `jobs.rejected` | 1 | 3 days | Rejected jobs |
| `applications.submitted` | 3 | 90 days | Submitted applications (audit) |

## Database Schema

8 tables with Row-Level Security enabled on all user-facing tables.
See `db/schema.sql` for full DDL including indexes, triggers, and RLS policies.

## Security (Implemented in Week 1)

- RLS on all user-facing tables (candidates, experiences, skills, truth_constraints, applications, resume_versions, audit_log)
- Immutable audit log (triggers prevent UPDATE/DELETE)
- Vault dev mode with AppRole auth + 5-min TTL tokens
- AES-256 encryption key provisioned in Vault (used in Week 5+)
- Kafka ACLs with least-privilege per agent

## Teardown

```bash
# Stop containers, keep data
./scripts/dev-down.sh

# Nuclear option — destroy everything
./scripts/dev-down.sh --clean
```

## Next: Week 2

- Agent 1: Scout (Greenhouse/Lever/Ashby API polling)
- Kafka producer → `jobs.raw` topic
- Deploy Scout to AWS Lambda via CI
- Schema Registry with Avro schemas for job events
