#!/usr/bin/env python3
"""
Verify the PostgreSQL schema was applied correctly.
Usage: python scripts/validate_schema.py
"""

import os
import sys

import psycopg2

EXPECTED_TABLES = [
    "candidates",
    "experiences",
    "skills",
    "truth_constraints",
    "jobs",
    "applications",
    "resume_versions",
    "audit_log",
]

EXPECTED_ENUMS = [
    "visa_status",
    "ats_platform",
    "job_status",
    "application_status",
    "proficiency_level",
]


def main():
    conn = psycopg2.connect(
        host=os.getenv("PG_HOST", "localhost"),
        port=int(os.getenv("PG_PORT", "5432")),
        dbname=os.getenv("PG_DATABASE", "careerpilot"),
        user=os.getenv("PG_USER", "careerpilot"),
        password=os.getenv("PG_PASSWORD", "localdev123"),
    )
    cur = conn.cursor()
    errors = []

    # Check tables
    cur.execute("""
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
    """)
    existing_tables = {row[0] for row in cur.fetchall()}

    for table in EXPECTED_TABLES:
        if table in existing_tables:
            cur.execute(f"SELECT COUNT(*) FROM information_schema.columns WHERE table_name = '{table}'")
            col_count = cur.fetchone()[0]
            print(f"  ✅ {table} ({col_count} columns)")
        else:
            errors.append(f"Missing table: {table}")
            print(f"  ❌ {table} — MISSING")

    # Check enums
    cur.execute("SELECT typname FROM pg_type WHERE typtype = 'e'")
    existing_enums = {row[0] for row in cur.fetchall()}

    print("\nEnum types:")
    for enum in EXPECTED_ENUMS:
        if enum in existing_enums:
            print(f"  ✅ {enum}")
        else:
            errors.append(f"Missing enum: {enum}")
            print(f"  ❌ {enum} — MISSING")

    # Check RLS enabled
    print("\nRow Level Security:")
    cur.execute("""
        SELECT tablename, rowsecurity FROM pg_tables
        WHERE schemaname = 'public'
    """)
    for table_name, rls_enabled in cur.fetchall():
        if table_name in EXPECTED_TABLES:
            status = "✅ ON" if rls_enabled else "⚠️  OFF"
            print(f"  {status} {table_name}")

    # Check immutable audit triggers
    print("\nAudit log protection:")
    cur.execute("""
        SELECT trigger_name FROM information_schema.triggers
        WHERE event_object_table = 'audit_log'
    """)
    triggers = {row[0] for row in cur.fetchall()}
    for t in ["no_audit_update", "no_audit_delete"]:
        if t in triggers:
            print(f"  ✅ {t}")
        else:
            errors.append(f"Missing trigger: {t}")
            print(f"  ❌ {t} — MISSING")

    cur.close()
    conn.close()

    if errors:
        print(f"\n❌ {len(errors)} issue(s) found:")
        for e in errors:
            print(f"   • {e}")
        sys.exit(1)
    else:
        print("\n✅ All schema validations passed!")
        sys.exit(0)


if __name__ == "__main__":
    main()
