#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# CareerPilot — Local Dev Bootstrap
# Starts all services, waits for health checks, seeds topics.
#
# Usage: ./scripts/dev-up.sh
# ──────────────────────────────────────────────────────────────
set -euo pipefail

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

info()  { echo -e "${BOLD}${GREEN}▸${NC} $1"; }
warn()  { echo -e "${BOLD}${YELLOW}▸${NC} $1"; }
error() { echo -e "${BOLD}${RED}✗${NC} $1"; }

cd "$(dirname "$0")/.."

# ── Step 1: Start containers ────────────────────────────────
info "Starting docker-compose services..."
docker compose up -d

# ── Step 2: Wait for PostgreSQL ──────────────────────────────
info "Waiting for PostgreSQL..."
RETRIES=30
until docker compose exec -T postgres pg_isready -U careerpilot -q 2>/dev/null; do
  RETRIES=$((RETRIES - 1))
  if [ "$RETRIES" -le 0 ]; then
    error "PostgreSQL failed to start"
    exit 1
  fi
  sleep 1
done
info "PostgreSQL is ready"

# ── Step 3: Apply schema (idempotent — uses IF NOT EXISTS) ──
info "Applying database schema..."
docker compose exec -T postgres psql -U careerpilot -d careerpilot \
  -f /docker-entrypoint-initdb.d/01-schema.sql 2>&1 | \
  grep -v "already exists" || true
info "Schema applied"

# ── Step 4: Wait for Kafka broker ───────────────────────────
info "Waiting for Kafka broker..."
RETRIES=60
until docker compose exec -T broker kafka-broker-api-versions \
  --bootstrap-server localhost:9092 >/dev/null 2>&1; do
  RETRIES=$((RETRIES - 1))
  if [ "$RETRIES" -le 0 ]; then
    error "Kafka broker failed to start"
    exit 1
  fi
  sleep 2
done
info "Kafka broker is ready"

# ── Step 5: Wait for topic creation ─────────────────────────
info "Waiting for topic initialization..."
sleep 5  # topic-init container runs after broker is healthy
TOPICS=$(docker compose exec -T broker kafka-topics \
  --bootstrap-server localhost:9092 --list 2>/dev/null | grep -c "^jobs\.\|^applications\." || true)
if [ "$TOPICS" -ge 5 ]; then
  info "All 5 Kafka topics created"
else
  warn "Only $TOPICS/5 topics detected — check topic-init logs"
fi

# ── Step 6: Wait for Vault ──────────────────────────────────
info "Waiting for Vault..."
RETRIES=20
until docker compose exec -T vault vault status >/dev/null 2>&1; do
  RETRIES=$((RETRIES - 1))
  if [ "$RETRIES" -le 0 ]; then
    error "Vault failed to start"
    exit 1
  fi
  sleep 1
done
info "Vault is ready (dev mode, token: root)"

# ── Step 7: Wait for Redis ──────────────────────────────────
info "Waiting for Redis..."
RETRIES=10
until docker compose exec -T redis redis-cli ping 2>/dev/null | grep -q PONG; do
  RETRIES=$((RETRIES - 1))
  if [ "$RETRIES" -le 0 ]; then
    error "Redis failed to start"
    exit 1
  fi
  sleep 1
done
info "Redis is ready"

# ── Summary ──────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}═══════════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN} CareerPilot Local Dev Environment Ready${NC}"
echo -e "${BOLD}${GREEN}═══════════════════════════════════════════════${NC}"
echo ""
echo -e "  PostgreSQL:           ${BOLD}localhost:5432${NC}  (careerpilot/localdev123)"
echo -e "  Kafka Broker:         ${BOLD}localhost:9092${NC}"
echo -e "  Schema Registry:      ${BOLD}http://localhost:8081${NC}"
echo -e "  Kafka Connect:        ${BOLD}http://localhost:8083${NC}"
echo -e "  ksqlDB:               ${BOLD}http://localhost:8088${NC}"
echo -e "  Control Center:       ${BOLD}http://localhost:9021${NC}"
echo -e "  Vault:                ${BOLD}http://localhost:8200${NC}  (token: root)"
echo -e "  Redis:                ${BOLD}localhost:6379${NC}"
echo -e "  Redis Commander:      ${BOLD}http://localhost:8082${NC}"
echo ""
echo -e "  ${BOLD}Next step:${NC} cp .env.example .env && add your API keys"
echo -e "  ${BOLD}Run Agent 0:${NC} python -m agent0 resume.pdf --user-id <uuid>"
echo ""
