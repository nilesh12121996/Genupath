#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# CareerPilot — Local Dev Teardown
# Usage:
#   ./scripts/dev-down.sh          # stop containers, keep data
#   ./scripts/dev-down.sh --clean  # stop + delete volumes
# ──────────────────────────────────────────────────────────────
set -euo pipefail

cd "$(dirname "$0")/.."

if [[ "${1:-}" == "--clean" ]]; then
  echo "⚠️  Destroying all containers AND volumes..."
  docker compose down -v --remove-orphans
  echo "✅ All containers and volumes removed."
else
  echo "Stopping containers (data preserved in volumes)..."
  docker compose down --remove-orphans
  echo "✅ Containers stopped. Run ./scripts/dev-up.sh to restart."
fi
